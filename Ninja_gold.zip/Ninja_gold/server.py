import random
from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key ="sKey"
@app.route('/')
def index():
    if 'yourgold' not in session:
        session['yourgold']=0
    if 'action' not in session:
        session['action']=""
    return render_template('index.html')
@app.route('/process_money', methods=['POST'])
def process_money():
    activity = request.form['process']
    print activity
    gold = 0
    if activity == "farm":
        gold = random.randint(10,20)
        print gold
    elif activity == "cave":
        gold = random.randint(5,10)
        print gold
    elif activity == "house":
        gold = random.randint(2,5)
        print gold
    if activity == "casino":
        if session['yourgold'] > 50:
            gold = random.randint(-50,50)
        print gold
    session['action']= session['action'] + "Earned " +str(gold)+ " from the " +activity+ "!"
    print session['yourgold']
    return render_template('index.html', yourgold=session['yourgold'], action=session['action'])
app.run(debug=True)
